
CardPaySuite
============

A lightweight fintech educational website ready for GoDaddy Web Starter Hosting.
Files are plain HTML/CSS/JS and small PHP endpoints.

How to deploy:
1. Unzip CardPaySuite.zip
2. Upload the unzipped folder contents to your GoDaddy Web Starter Hosting public_html (or root site folder) via File Manager or FTP.
3. Edit php/contact.php and set $recipient to your email address.
4. Ensure PHP mail() is allowed by your host or configure an SMTP relay if needed.
5. Visit the site URL. No build steps required.

Security & Privacy:
- Tools run client-side and do not send pasted inputs to the server by default.
- Do not paste real card PANs into public/shared machines. This project is for education/testing only.
